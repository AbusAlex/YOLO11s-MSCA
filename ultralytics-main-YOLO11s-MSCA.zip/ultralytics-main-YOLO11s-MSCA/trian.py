import warnings

from ultralytics.models import RTDETR

warnings.filterwarnings('ignore')
from ultralytics import YOLO
#from ultralytics import RTDETR

if __name__ == '__main__':
    model = YOLO(r'.\ultralytics\cfg\models\v9\yolov9s.yaml')     #Your model configuration file
    model.train(data=r'.....your dataset path ........',   #  For example, my path is     '..\CBMdataset\CBM_data.yaml'
                cache=False,
                imgsz=640,
                epochs=100,
                single_cls=False,  # 是否是单类别检测
                batch=8,
                close_mosaic=10,
                workers=0,
                device='0',
                optimizer='SGD',
                amp=True,
                project='runs/CBM',
                name='yolov9s_CBM',
                )


