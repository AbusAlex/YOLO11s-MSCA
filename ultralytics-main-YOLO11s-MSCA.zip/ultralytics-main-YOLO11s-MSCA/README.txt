MSCA module code path :   .\ultralytics\nn\Addmodule\MSCA.py
YOLO11s-MSCA.yaml path:  .\ultralytics\cfg\models\11\yolo11MSCA.yaml


The download address of the dataset is as follows:
D-Fire：https://github.com/gaiasd/DFireDataset
Fire and Smoke Dataset：https://github.com/CostiCatargiu/NEWFireSmokeDataset_YoloModels
CBM-Fire：  https://github.com/GengHan-123/yolov9-cbm.git.
