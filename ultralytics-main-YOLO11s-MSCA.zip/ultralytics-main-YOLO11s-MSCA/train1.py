import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r'C:\Users\LYX\Desktop\ultralytics-main\ultralytics-main-YOLO11s-MSCA\ultralytics\cfg\models\11\yolo11MSCA.yaml')
    model.train(data=r'C:\Users\LYX\Desktop\yolo\FASDD_CV\YOLO_FASDD\FASDD_data.yaml',
                cache=False,
                imgsz=640,
                epochs=100,
                single_cls=False,  # 是否是单类别检测
                batch=20,
                close_mosaic=10,
                workers=0,
                device='2',
                optimizer='SGD',
                amp=True,
                project='runs/CBM',
                name='YOLO11s_MSCA_FASDD',
                )